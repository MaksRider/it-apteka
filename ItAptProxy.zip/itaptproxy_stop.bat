rem Stop nginx as Windows Service
C:
cd C:\itapteka-proxy\
itapteka-proxy.exe stop
timeout 5