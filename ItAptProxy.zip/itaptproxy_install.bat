rem Install nginx as Windows Service
C:
cd C:\itapteka-proxy\
itapteka-proxy.exe install