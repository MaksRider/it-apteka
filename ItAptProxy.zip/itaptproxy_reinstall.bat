rem Re-Install nginx as Windows Service
C:
cd C:\itapteka-proxy\
itapteka-proxy.exe stop
timeout 5
itapteka-proxy.exe uninstall
itapteka-proxy.exe install
itapteka-proxy.exe start