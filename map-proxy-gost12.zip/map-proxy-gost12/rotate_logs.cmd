@echo off

del /F C:\map-proxy-gost12\nginx\logs\access.old
del /F C:\map-proxy-gost12\nginx\logs\error.old
move /Y C:\map-proxy-gost12\nginx\logs\access.log C:\map-proxy-gost12\nginx\logs\access.old
move /Y C:\map-proxy-gost12\nginx\logs\error.log C:\map-proxy-gost12\nginx\logs\error.old
C:\map-proxy-gost12\map-proxy-gost12.exe restart map-proxy-gost12