rem Re-Install nginx as Windows Service
C:
cd C:\map-proxy-gost12\
map-proxy-gost12.exe stop
timeout 5
map-proxy-gost12.exe uninstall
