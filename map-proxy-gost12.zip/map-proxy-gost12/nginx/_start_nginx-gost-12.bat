@echo off
set NGINX_BIN=nginx-gost-12
set GOST_ENGINE=gostengy
set GOST_ENGINE_PATH=%~dp0%GOST_ENGINE%.dll
set GOST_ENGINE_PATH=%GOST_ENGINE_PATH:\=\\%
set OPENSSL_CONF=%~dp0openssl.cnf

(echo openssl_conf = openssl_def) > %OPENSSL_CONF%
(echo.) >> %OPENSSL_CONF%
(echo [openssl_def]) >> %OPENSSL_CONF%
(echo engines = engine_section) >> %OPENSSL_CONF%
(echo.) >> %OPENSSL_CONF%
(echo [engine_section]) >> %OPENSSL_CONF%
(echo %GOST_ENGINE% = %GOST_ENGINE%_section) >> %OPENSSL_CONF%
(echo.) >> %OPENSSL_CONF%
(echo [%GOST_ENGINE%_section]) >> %OPENSSL_CONF%
(echo engine_id = %GOST_ENGINE%) >> %OPENSSL_CONF%
(echo dynamic_path = %GOST_ENGINE_PATH%) >> %OPENSSL_CONF%
(echo default_algorithms = CIPHERS, DIGESTS, PKEY, PKEY_CRYPTO, PKEY_ASN1) >> %OPENSSL_CONF%

cd /d %~dp0
%NGINX_BIN%.exe -V
@echo on
%NGINX_BIN%.exe
@pause
