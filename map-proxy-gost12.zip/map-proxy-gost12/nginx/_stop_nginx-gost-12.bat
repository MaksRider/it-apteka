@set NGINX_BIN=nginx-gost-12
taskkill /f /im %NGINX_BIN%.exe
