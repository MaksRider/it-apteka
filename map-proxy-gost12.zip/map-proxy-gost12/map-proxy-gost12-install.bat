rem Install nginx as Windows Service
C:
cd C:\map-proxy-gost12\
map-proxy-gost12.exe install
map-proxy-gost12.exe start
